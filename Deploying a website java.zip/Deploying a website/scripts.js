// script.js

// Add an event listener to the window's load event
window.onload = function () {
    // Find the button element by its class name
    var generateQuoteButton = document.querySelector('.generate-quote-button');

    // Add a click event listener to the button
    generateQuoteButton.addEventListener('click', generateQuote);
};

function generateQuote() {
    // Your existing logic for generating a quote
    var modelSelect = document.getElementById('modelSelect');
    var durationInput = document.getElementById('durationInput');
    var quoteResult = document.getElementById('quoteResult');

    var selectedModel = modelSelect.value;
    var duration = parseFloat(durationInput.value);
    var costPerDay = 0;

    // Set the cost per day based on the selected model
    if (selectedModel === 'XYZ') {
        costPerDay = 100;
    } else if (selectedModel === 'CPRG') {
        costPerDay = 213;
    }

    // Calculate the total cost
    var totalCost = costPerDay * duration;

    // Display the result
    quoteResult.innerHTML = "The cost to book " + selectedModel + " for " + duration + " days is $" + totalCost.toFixed(2) + ".";
}
